## Entorno virtual

Crear el entorno virtual, activarlo e instalar los paquetes:

```
python -m venv .venv

.\.venv\Scripts\activate

pip install flask joblib scikit-learn pandas numpy

```
